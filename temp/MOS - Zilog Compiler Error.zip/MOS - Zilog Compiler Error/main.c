/*
 * Title:			AGON MOS
 * Author:			Dean Belfield
 * Created:			22/08/2022
 * Last Updated:	22/08/2022
 *
 * Modinfo:
 * 22/08/2022:		Distilled version to illustrate bug
 */

#include <eZ80.h>
#include <defines.h>
#include <stdio.h>
#include <CTYPE.h>
#include <String.h>

#include "ff.h"

// To trigger the compilation error, open src_fatfs/ffconf.h and edit line 116
//
// #define FF_USE_LFN		0
//
// Set it to 0 and it triggers a compilation error "P2: Internal Error(0xB47E59)" in src_fatfs/ff.c
// Set it to 2 and it compiles fine
//
// Then do a Rebuild All
//
// The define is for optional compilation of parts of src_fatfs/ff.c
// This code is a distilled example just for this compiler error bug
// Thank you for your help
//
// Dean Belfield @breakintoprog

int main(void) {
	return 0;
}